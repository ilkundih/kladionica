export class Ticket{
    participants : any;
    odd : number;
    pick : string;
    eventId : string;
}