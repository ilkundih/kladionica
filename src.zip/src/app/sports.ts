export class Sport{
    id: string;
    order: number;
    name: string;
}