export class League {
    id: string;
    name: string;
    order: number;
    iconId: string;
    locatioName: string;
    locationId: string;
    locationOrder: number;
}