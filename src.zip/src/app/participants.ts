export class Participants {
    id: string;
    name: string;
    position: number;
}