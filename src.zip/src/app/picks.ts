export class Picks{
    id: string;
    name: string;
    order: number;
    status: number;
}